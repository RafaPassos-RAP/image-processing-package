# img_processing

Description. 
The package package_name is used to:
	Processing:
		- Histrogram matching
		- Structural similarity
		- Resize Image
	Util:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install img_processing
```

## Usage

```python
from img_processing.processing import transformation
result = transformation.sua_funcao(img)
```

## Author
Rafael

## License
[MIT](https://choosealicense.com/licenses/mit/)